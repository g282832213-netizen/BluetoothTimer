package com.example.bluetoothtimer

import android.app.*
import android.content.Intent
import android.os.*

class TimerService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private var endAt = 0L
    private var pausedRemaining = 0L
    private var running = false

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            val left = endAt - SystemClock.elapsedRealtime()
            if (left <= 0) {
                running = false
                getSharedPreferences("timer", MODE_PRIVATE).edit().clear().apply()
                sendBroadcast(Intent(BluetoothAccessibilityService.ACTION_CLOSE_BLUETOOTH).setPackage(packageName))
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            } else {
                updateNotification(left)
                handler.postDelayed(this, 1000)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        val channel = NotificationChannel(CHANNEL, "蓝牙倒计时", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val seconds = intent.getLongExtra(EXTRA_SECONDS, 0)
                if (seconds <= 0) { stopSelf(); return START_NOT_STICKY }
                endAt = SystemClock.elapsedRealtime() + seconds * 1000
                running = true
                pausedRemaining = 0
                startForeground(NOTIFICATION_ID, notification("倒计时进行中"))
                handler.removeCallbacks(tick)
                handler.post(tick)
            }
            ACTION_PAUSE -> {
                if (running) {
                    pausedRemaining = (endAt - SystemClock.elapsedRealtime()).coerceAtLeast(0)
                    running = false
                    handler.removeCallbacks(tick)
                    updateNotification(pausedRemaining)
                }
            }
            ACTION_CANCEL -> {
                running = false
                handler.removeCallbacks(tick)
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    private fun notification(line: String): Notification = Notification.Builder(this, CHANNEL)
        .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
        .setContentTitle("蓝牙定时关闭")
        .setContentText(line)
        .setOngoing(true)
        .build()

    private fun updateNotification(ms: Long) {
        val total = (ms / 1000).coerceAtLeast(0)
        val text = "%02d:%02d:%02d".format(total / 3600, (total % 3600) / 60, total % 60)
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, notification("剩余 $text"))
    }

    override fun onBind(intent: Intent?) = null

    companion object {
        const val ACTION_START = "start"
        const val ACTION_PAUSE = "pause"
        const val ACTION_CANCEL = "cancel"
        const val EXTRA_SECONDS = "seconds"
        private const val CHANNEL = "bluetooth_timer"
        private const val NOTIFICATION_ID = 1001
    }
}
