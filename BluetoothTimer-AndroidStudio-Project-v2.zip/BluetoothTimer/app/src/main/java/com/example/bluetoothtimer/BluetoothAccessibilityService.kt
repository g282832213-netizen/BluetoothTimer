package com.example.bluetoothtimer

import android.accessibilityservice.AccessibilityService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class BluetoothAccessibilityService : AccessibilityService() {
    private var actionPending = false
    private var clickAttempted = false

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != ACTION_CLOSE_BLUETOOTH) return
            actionPending = true
            clickAttempted = false
            val settings = Intent(Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try { startActivity(settings) } catch (_: Exception) { actionPending = false }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        val filter = IntentFilter(ACTION_CLOSE_BLUETOOTH)
        if (android.os.Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        else registerReceiver(receiver, filter)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!actionPending || clickAttempted || event == null) return
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            event.eventType != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) return

        val root = rootInActiveWindow ?: return
        val switchNode = findBluetoothSwitch(root) ?: return

        // Fail closed: only click a clearly checked switch. Unknown state means no action.
        val isOn = switchNode.isChecked
        if (isOn) {
            clickAttempted = true
            val clickable = clickableAncestor(switchNode) ?: switchNode
            clickable.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        } else {
            // Already off: do nothing. Never toggle it on.
            actionPending = false
        }
    }

    private fun findBluetoothSwitch(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val cls = node.className?.toString().orEmpty()
        val text = (node.text?.toString() + " " + node.contentDescription?.toString()).lowercase()
        if ((cls.contains("Switch", true) || cls.contains("CompoundButton", true)) &&
            (text.contains("bluetooth") || node.viewIdResourceName?.contains("switch", true) == true)) {
            return node
        }
        for (i in 0 until node.childCount) {
            val found = node.getChild(i)?.let { findBluetoothSwitch(it) }
            if (found != null) return found
        }
        return null
    }

    private fun clickableAncestor(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var current: AccessibilityNodeInfo? = node
        repeat(5) {
            if (current?.isClickable == true) return current
            current = current?.parent
        }
        return null
    }

    override fun onInterrupt() {}
    override fun onDestroy() {
        try { unregisterReceiver(receiver) } catch (_: Exception) {}
        super.onDestroy()
    }

    companion object { const val ACTION_CLOSE_BLUETOOTH = "com.example.bluetoothtimer.CLOSE_BLUETOOTH" }
}
